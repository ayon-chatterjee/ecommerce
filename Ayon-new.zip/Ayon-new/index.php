
<html lang="en">
    
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/responsive.css" />
        <link rel="stylesheet" href="css/style.css" />
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="banner col-s-12 col-12">
            <div class="header">
                
                <div class="header-right col-6">
                    <ul class="header-menu">
                        <li><a href="#"><span style="margin-right:2%;" class="glyphicon glyphicon-shopping-cart"></span>Track Order</a></li>
                        <li><a href="#"><span style="margin-right:2%;" class="glyphicon glyphicon-phone"></span>Download App</a></li>
                        <li><a href="#"><span style="margin-right:2%;" class="glyphicon glyphicon-user"></span>Customer Service</a></li>
                    </ul>
                </div>
            </div>
            <div class="logo col-s-12 col-12">
                <div style=" text-align:center; margin-top:15%; height:auto; width:auto;">
                    <img  id="logoimage" src="img/logo1.png" style="transform:scale(2,2);" />
                </div>
            </div>
            <div class="login col-s-12 col-12" style="text-align:center;">
                <button type="button" class="btn">DIVE IN<span style="margin-left:15px; margin-top:0px;" class="glyphicon glyphicon-arrow-right"></span></button>
            </div>
        
        
        <!-- Login Tab starts -->

                <div class="col-4" style="float:left;">&emsp;</div>
                <div id="loginpage" class="loginpage col-4 col-s-12" style="float:left;">

                    <div style="float:right;"><span id="remove-overlay" class="glyphicon glyphicon-remove" style="margin:5px 5px 0px 0px;"></span></div><br/><br/>
                    <ul class="nav nav-tabs">
                        <li class="active" style="width:50%; padding-left:5px;"><a data-toggle="tab" href="#userlogin">Login</a></li>
                        <li style="padding-left:5px;"><a data-toggle="tab" href="#signup">Sign Up</a></li>
                        
                        
                    </ul>

                    <div class="tab-content">
                        <div id="userlogin" class="tab-pane fade in active" style="padding:20px;" >
                            
                            Email Id:<br/>
                            <input type="email" class="form-control" id="emailforlogin" style="width:100%;" spellcheck="false"/><br/><br/>
                            Password:<br/>
                            <input type="password" class="form-control" id="passforlogin" style="width:100%;" spellcheck="false"/><br/><br/>
                            <button type="button" class="btn">Sign In<span style="margin-left:15px;" class="glyphicon glyphicon-arrow-right"></span></button>
                            
                        </div>
                        <div id="signup" class="tab-pane fade" style="padding:20px;"> 
                           Email Id:<br/>
                           <input type="email" class="form-control" id="emailforsignup" style="width:100%;" spellcheck="false"/><br/>
                           Password:<br/>
                           <input type="password" class="form-control" id="passforsignup" style="width:100%;" spellcheck="false"/><br/>
                            Confirm Password:<br/>
                           <input type="password" class="form-control" id="passconfirmforsignup" style="width:100%;" spellcheck="false"/><br/>
                           <button type="button" class="btn">Sign Up<span style="margin-left:15px;" class="glyphicon glyphicon-arrow-right" spellcheck="false"></span></button>
                        </div>
                        
                    </div>
                </div>
            
        <!-- Login Tab ends -->
        </div>
        <div class="about">
            <div class="about-header col-12 col-s-12">
                ABOUT
            </div>
            <div class="about-contents col-12 col-s-12"  style="padding-top:70px;">
                <div class="col-s-12 col-1">&emsp;</div>
                <div class="about-contents-left col-s-12 col-5" style="letter-spacing:2px;">
                    <div style="color:#ef374c; font-size:28px; letter-spacing:4px;">WHY WE BEAT</div><br/>
                    <div>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sed odio consequat, tristique elit sed, molestie nulla. Mauris et quam leo. Quisque tincidunt facilisis rutrum. Etiam mattis arcu vitae velit sagittis vehicula. Duis posuere ex in mollis iaculis. Suspendisse tincidunt ut velit id euismod.vulputate turpis porta ex sodales, dignissim hendrerit eros sagittis. </p>
                    </div><br/>
                    <button type="button" class="btn">Read More</button>
                </div>
                <div class="col-s-12 col-1">&emsp;</div>
                <div class="about-contents-right col-s-12 col-5">
                        
                      <img src="img/aboutimage.jpg" title="About" alt="About" />  

                </div>
            </div>
            <div class="col-12 col-s-12" style="height:100px; float:left;"></div>
        </div>
        <div class="services col-s-12 col-12">
            <div class="services-header col-12 col-s-12">
                SERVICES
            </div>
            <div style="margin-top:50px; position:relative;" class="services-details col-12 col-s-12">
                <div class="col-s-12 col-2">&emsp;</div>
                <div class="blogs service-card col-s-12 col-2">
                    <div class="service-icon">
                        <i class="fab fa-blogger" aria-hidden="true" style="font-size:50px; background:white;"></i>  
                    </div>
                    <div class="service-heading"><a href="#">Blogs</a></div> 
                    <div class="service-card-details">tur aut.maiores alias consequa</div>                   
                </div>
                <div class="col-1 col-s-12">&emsp;</div>
                <div class="newspaper service-card col-s-12 col-2">
                    <div class="service-icon">
                        <i class="far fa-newspaper" aria-hidden="true" style="font-size:50px;"></i>
                    </div>
                    <div class="service-heading"><a href="#">Newspaper</a></div> 
                    <div class="service-card-details">tur aut.maiores alias consequa</div>
                </div>
                <div class="col-1 col-s-12">&emsp;</div>
                <div class="magazines service-card col-s-12 col-2">
                     <div class="service-icon">
                        <i class="far fa-newspaper" aria-hidden="true" style="font-size:50px; font-weight:800;"></i>

                    </div>
                    <div class="service-heading"><a href="#">Magazines</a></div> 
                    <div class="service-card-details">tur aut.maiores alias consequa</div>
                </div>
                <div class="col-s-12 col-2">&emsp;</div>
            </div>
            <div class="services-more col-s-12 col-12" style="margin-top:40px;">
                
                <button type="button" class="btn">Other Products</button>
            </div>
        </div>
        <div class="newsletter col-s-12 col-12">
            <div class="newsletter-header col-12 col-s-12">
                NEWS &nbsp;LETTER
            </div>
            <div class="newsletter-contents col-s-12 col-12">
                <div class="col-s-12 col-1">&emsp;</div>
                <div class="col-s-12 col-10">
                    <input type="text" class="form-control col-s-12 col-3" placeholder="Name" spellcheck="false"/>
                    <div class="col-s-12 col-1">&emsp;</div>
                    <input type="email" class=" form-control col-s-12 col-3" placeholder="Email" spellcheck="false"/>
                    <div class="col-s-12 col-1">&emsp;</div>
                    <input type="email" class=" form-control col-s-12 col-3" placeholder="City" spellcheck="false"/>
                    <div class="col-s-12 col-1">&emsp;</div>
                </div>    
                
                <div class="col-s-12 col-1">&emsp;</div>
            </div>
            <div class="newsletter-send col-12 col-s-12">
                <div class="col-s-12 col-5" >&emsp;</div>
                <button type="button" class="btn col-s-12 col-2">SEND</button>
                <div class="col-s-12 col-5" >&emsp;</div>
            </div>
        </div>
        <div class="contact col-s-12 col-12">
            <div class="contact-header col-12 col-s-12">
                CONTACT
            </div>
            <div class="col-12 col-s-12" style="margin-top:50px;">
                <div class="col-s-12 col-1">&emsp;</div>
                <div class="contact-contents col-s-12 col-10">
                    <form class="submit-message col-s-12 col-7">
                        <input type="text" class="form-control col-s-12 col-5" placeholder="Name" />
                        <div class="col-s-12 col-2">&emsp;</div>
                        <input type="text" class="form-control col-s-12 col-5" placeholder="Last Name" />
                        <div class="col-s-12 col-12">&emsp;</div>
                        <input type="email" class="form-control col-s-12 col-5" placeholder="Email" />
                        <div class="col-s-12 col-2">&emsp;</div>
                        <input type="text" class="form-control col-s-12 col-5" placeholder="Phone" />
                        <div class="col-s-12 col-12">&emsp;</div>
                        <textarea class="form-control rounded-0" rows="10" placeholder="Message" style="height:200px;"></textarea>
                        <div class="col-s-12 col-12">&emsp;</div>
                        <button type="button" class="btn col-s-12 col-12">SEND</button>        
                    </form>
                    
                    
                    <div class="col-s-12 col-1">&emsp;</div>
                    <div class="col-s-12 col-4"><iframe class="location-map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29435.564419319006!2d88.32023728942316!3d22.748840595891803!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f89b2213f5a85b%3A0x3a2ead22f174a6e2!2sSerampore%2C+West+Bengal!5e0!3m2!1sen!2sin!4v1530015573412" style="width:100%; height:175px;" frameborder="0" style="border:0" allowfullscreen ></iframe>
                        <div class="col-s-12 col-12">&emsp;</div>
                        <div class="col-s-12 col-12">
                            <div style="font-size:22px; color:#ef374c;">Address</div>
                            <div style="margin-bottom:5px;">1234k Avenue, 4th block,<br/>New York, USA</div>
                        </div>
                        <div class="col-s-12 col-12">
                            <div style="font-size:22px; color:#ef374c;">Contact Us</div>
                            <div style="margin-bottom:5px;">+(000) 123 4565 32</div>
                        </div>
                        <div class="col-s-12 col-12">
                            <div style="font-size:22px; color:#ef374c;">Email Us</div>
                            <div style="margin-bottom:5px;">info@example1.com</div>
                        </div>
                    </div>
                </div>
                
                <div class="col-s-12 col-1">&emsp;</div>
            </div>
        </div>
        <div class="footer col-s-12 col-12">
            
            
                <ul class="footer-top col-s-12 col-12" style="text-align:center;">
                    <a href="#"><li>Jobs</li></a>
                    <a href="#"><li>Careers</li></a>
                    <a href="#"><li>Payments</li></a>
                    <a href="#"><li>Shipping</li></a>
                    <a href="#"><li>Cancellation & Returns</li></a>
                    <a href="#"><li>FAQ</li></a>
                </ul>
            
          <div class="footer-bottom col-12 col-s-12">
            <div class="col-1 col-s-12">&emsp;</div>
            <div class="col-2 col-s-12" style="font-size:26px; text-align:center;">MORNING TIME</div>
            <div class="col-6 col-s-12" style="text-align:center; line-height:40px;">&#169;&nbsp;2018 Morning Time. All Rights Reserved | Design and developed by Raktim Malakar</div>
            <div class="footer-icons col-2 col-s-12" style="line-height:40px;">
                <ul style="text-align:center;" class="col-12 col-s-12">
                    <a href="#" title="facebook"><li><i class=" fa fa-facebook-f" aria-hidden="true"></i></li></a>
                    <a href="#" title="twitter"><li><i class="fa fa-twitter" aria-hidden="true"></i></a></li></a>
                    <a href="#" title="google plus"><li><i class="fa fa-google-plus" aria-hidden="true"></i></a></li></a>
                    <a href="#" title="gmail"><li><i class="fa fa-envelope" aria-hidden="true"></i></a></li></a>
                </ul>

            </div>
            <div class="col-1 col-s-12">&emsp;</div>
            </div>
        </div>
        <script src="js/script.js"></script>
    </body>

</html>

