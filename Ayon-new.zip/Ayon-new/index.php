
<html lang="en">
    
    <head>
        <title>Bootstrap Example</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="css/responsive.css" />
        <link rel="stylesheet" href="css/style.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="banner col-s-12 col-12">
            <div class="header">
                
                <div class="header-right col-6">
                    <ul class="header-menu">
                        <li><a href="#"><span style="margin-right:2%;" class="glyphicon glyphicon-shopping-cart"></span>Track Order</a></li>
                        <li><a href="#"><span style="margin-right:2%;" class="glyphicon glyphicon-phone"></span>Download App</a></li>
                        <li><a href="#"><span style="margin-right:2%;" class="glyphicon glyphicon-user"></span>Customer Service</a></li>
                    </ul>
                </div>
            </div>
            <div class="logo col-s-12 col-12">
                <div style=" text-align:center; margin-top:18%; height:auto; width:auto;">
                    <img  id="logoimage" src="img/logo1.png" style="transform:scale(1,1);" />
                </div>
            </div>
            <div class="login col-s-12 col-12" style="text-align:center;">
                <button type="button" class="btn">DIVE IN<span style="margin-left:15px;" class="glyphicon glyphicon-arrow-right"></span></button>
            </div>
        </div>
        
        <!-- Login Tab starts -->

                <div class="col-4">&emsp;</div>
                <div id="loginpage" class="loginpage col-4 col-s-12">

                    <div style="float:right;"><span id="remove-overlay" class="glyphicon glyphicon-remove" style="margin:5px 5px 0px 0px;"></span></div><br/><br/>
                    <ul class="nav nav-tabs">
                        <li class="active" style="width:50%; padding-left:5px;"><a data-toggle="tab" href="#userlogin">Login</a></li>
                        <li style="padding-left:5px;"><a data-toggle="tab" href="#signup">Sign Up</a></li>
                        
                        
                    </ul>

                    <div class="tab-content">
                        <div id="userlogin" class="tab-pane fade in active" style="padding:20px;" >
                            
                            Email Id:<br/>
                            <input type="email" class="form-control" id="emailforlogin" style="width:100%;"/><br/><br/>
                            Password:<br/>
                            <input type="password" class="form-control" id="passforlogin" style="width:100%;"/><br/><br/>
                            <button type="button" class="btn">Sign In<span style="margin-left:15px;" class="glyphicon glyphicon-arrow-right"></span></button>
                            
                        </div>
                        <div id="signup" class="tab-pane fade" style="padding:20px;"> 
                           Email Id:<br/>
                           <input type="email" class="form-control" id="emailforsignup" style="width:100%;"/><br/>
                           Password:<br/>
                           <input type="password" class="form-control" id="passforsignup" style="width:100%;"/><br/>
                            Confirm Password:<br/>
                           <input type="password" class="form-control" id="passconfirmforsignup" style="width:100%;"/><br/>
                           <button type="button" class="btn">Sign Up<span style="margin-left:15px;" class="glyphicon glyphicon-arrow-right"></span></button>
                        </div>
                        
                    </div>
                </div>

        <!-- Login Tab ends -->

        
        <script src="js/script.js"></script>
    </body>

</html>

