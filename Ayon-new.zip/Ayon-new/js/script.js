$(document).ready(function(){
    $(".loginpage").hide();
});



$(document).ready(function(){
    $(".login").click(function(){
        $("#logoimage").hide();        
        $(".loginpage").fadeIn(200);
        $(".login .btn").hide();        
        $(".logo").hide();
    });
});

$(document).ready(function(){
    $("#remove-overlay").click(function(){
        $("#logoimage").show();
        $(".logo").show(); 
        $(".login .btn").show();        
        $(".loginpage").fadeOut(200);        
    });
});

$(document).ready(function(){
    document.getElementById("abc").disabled=false;
});
