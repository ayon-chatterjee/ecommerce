$(document).ready(function(){
    $(".loginpage").hide();
});



$(document).ready(function(){
    $(".login .btn").click(function(){
        $("#logoimage").hide();        
        
        $(".login .btn").hide();        
        $(".logo").hide();
        $(".loginpage").fadeIn(200);
    });
});

$(document).ready(function(){
    $("#remove-overlay").click(function(){
        $(".loginpage").fadeOut(200);        
        $("#logoimage").show();
        $(".logo").show(); 
        $(".login .btn").show();        
                
    });
});


